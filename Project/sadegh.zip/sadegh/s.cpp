#include <iostream>
#include <string>
#include <fstream>
using namespace std;
string str[11];
int curr[10]={0};
string merg="";
bool is_big(string a ,string b)
	{
	if(a.length()>b.length())
		return true;
	else if(a.length()<b.length())
			return false;
		 else
		 	{
		 	for(int i=0;i<a.length();i++)
		 		if(a[i]!=b[i])
		 			{
		 			if(int(a[i])>int(b[i]))
		 				{return true;break;}
		 			else
		 				{return false;break;}
		 			}
		 	
		 	}
	}
int num_s(string s)
	{
	int count=0;
	for(int i=0;i<s.length();i++)
		if(s[i]==' ')
			count++;
	return count;	
	}

int wh_s(string s,int x)
	{
	int count=0;
	if(num_s(s) <= x)
		{
		return s.length();
		}
	else
	{
	for(int i=0;i<s.length();i++)
		{if(count==x)
			{return i;break;}
		if(s[i]==' ')
			count++;}
	return 0;
	}
	}
string swap(string s, int a, int b)
	{
	int x;
	string s1="",s2="",s3="",s4="",s5="";
	for(int i=0; i<a-1 ;i++)
		s1=s1+s[i];
	for(int i=a;i<b-1;i++)
		{
		if(s[i] != ' ')
			s2=s2+s[i];
		else
			{
			x=i;
			break;
			}
		}
	for(int i=x+1;i<b-1;i++)
		s3=s3+s[i];
	for(int i=b;i<s.length()-1;i++)
		s4=s4+s[i];	
	//cout<<"\ns1 : "<<s1<<"F\ns2 : "<<s2<<"F\ns3 : "<<s3<<"F\ns4 : "<<s4<<"F\n";
	if(is_big(s2,s3))
		{
		if(s1 !="" && s4 != "")
			return s1+" "+s2+" "+s3+" "+s4+" ";
		if(s1 =="" && s4 != "")
			return s2+" "+s3+" "+s4+" ";
		if(s1 !="" && s4 == "")
			return s1+" "+s2+" "+s3+" ";
		if(s1 =="" && s4 == "")
			return s2+" "+s3+" ";
		}
	else
		{
		if(s1 !="" && s4 != "")
			return s1+" "+s3+" "+s2+" "+s4+" ";
		if(s1 =="" && s4 != "")
			return s3+" "+s2+" "+s4+" ";
		if(s1 !="" && s4 == "")
			return s1+" "+s3+" "+s2+" ";
		if(s1 =="" && s4 == "")
			return s3+" "+s2+" ";
		}
	}
string res="";
void set_array(string s)
	{
	int n=num_s(s);
	n=n/10;
	int p1,p2;
	string p;
	for(int i=0 ;i<11;i++)
		str[i]="";
	for(int i=0;i<10;i++)
		{
		p1=wh_s(s,i*n);
		p2=wh_s(s,(i+1)*n);
		for(int j=p1;j<p2;j++)
			str[i]=str[i]+s[j];
		}                         

	if(num_s(s)%10 >0)
	{
	p1=wh_s(s,10*n);
	
		for(int j=p1;j<s.length();j++)
			res=res+s[j];
		str[10]=res;
	
	}
	}
void sub_sort(string s)
{
int n=num_s(s);
n=n/10;
int p1,p2;
set_array(s);
for(int u=0;u<10;u++)
	{
	for(int i=0 ; i<n ; i++)
		{
		for(int j=0;j<n-1 ;j++)
			{
			str[u]=swap(str[u],wh_s(str[u],j),wh_s(str[u],(j+2)));
			
			}
		}	
	}
if(str[10]!="")
{
for(int i=0 ; i<num_s(str[10]) ; i++)
		{
		for(int j=0;j<num_s(str[10])-1 ;j++)
			{
			str[10]=swap(str[10],wh_s(str[10],j),wh_s(str[10],(j+2)));
			
			}
		}	

}
}
string get_string(string s,int a)
{
string h="";
for(int i=wh_s(s,a);i<wh_s(s,a+1)-1;i++)
	h=h+s[i];
return h;
}
//a va b shomare khune araye str hastan
string mreg(int a,int b)
{
int x=num_s(str[a]);
int y=num_s(str[b]);
//cout<<"x : "<<x<<"\n"<<"y : "<<y<<endl;
string s1,s2,g;
int curr1=0,curr2=0;
string sort="";
for(int i=0;i<x+y;i++)
	{
	//cout<<"curr1 : "<<curr1<<"\n"<<"curr2 : "<<curr2<<endl;
	if(curr1 < x && curr2 < y)
	{
	s1=get_string(str[a],curr1);
	s2=get_string(str[b],curr2);
	if(is_big(s1,s2))
		{
		curr1++;
		sort=sort+s1+" ";
		}
	else
		{
		curr2++;
		sort=sort+s2+" ";
		}
	}
	if(curr1 < x && curr2 == y)
		{
		s1=get_string(str[a],curr1);
		curr1++;
		sort=sort+s1+" ";
		}
	if(curr1 == x && curr2 < y)
		{
		s2=get_string(str[b],curr2);
		curr2++;
		sort=sort+s2+" ";
		}
	
	
	}

return sort;
}
int main()
{
ifstream myfile;
ofstream my_file2;
string text="",line;
myfile.open("file.txt");
if (myfile.is_open())
  	{
    while ( myfile.good() )
   		{
	   		getline (myfile,line);
      		text=text+line;
    	}
    	myfile.close();
	}
sub_sort(text);
string d="11 33 22 44 ";
//cout<<"\n\n\n\n"<<str[10]<<endl;
//cout<<"\n"<<wh_s(d,1)<<"\n"<<num_s(d)<<"\n"<<wh_s(d,3)<<endl;
d=swap(d,wh_s(d,1),wh_s(d,3));
string w;
//cout<<"str[0] : "<<str[0]<<"F\n\n\n\n\n";
//cout<<"str[1] : "<<str[1]<<"F\n\n\n\n\n";
//cout<<w<<"F"<<endl;
int re,te;
if(str[10]=="")
	{re=9;te=10;}
else
	{re=10;te=11;}
ofstream myfile1;
string e="",k;
myfile1.open ("file2.txt");

for(int i=0;i<te;i++)
 	myfile1 << str[i]<<"\n";
myfile1.close();
cout<<"now in file2 is 10 line that in every line is sorted number : "<<endl;
string answer;
int count=0;

while(true)
	{
	cout<<"do you want i merg first and second ?(Y[es] or n[o])"<<endl;
	cin>>answer;
	if(answer=="n")
		break;
	else
		{
		if(count==re)
			{
			cout<<"i cant merg them !!!!"<<endl;
			break;
			}
		else
		{
		w=mreg(0,1);
		//e=e+w;
		str[0]=w;
		for(int i=1;i<te-1;i++)
			str[i]=str[i+1];
		str[te-count-1]="";
		
		//cout<<"w : "<<w<<endl;
		for(int i=0;i<te;i++)
 			e=e+str[i]+"\n";
 			
 		myfile1.open ("file2.txt");
 		myfile1 << e;
		myfile1.close();
		e="";
		count++;
		
		}
		
		
		}
	
	
	
	}


return 0;
}
