#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QtGui/QMainWindow>
#include <QGraphicsView>
#include "ascene.h"
#include <QMainWindow>
#include <QLabel>
#include <QString>
#include <QInputDialog>
#include <QLineEdit>
#include <string>
#include <QPen>
using namespace std;


class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    QGraphicsEllipseItem **y;
    QGraphicsLineItem **line;
    QGraphicsTextItem **txt;

    QLineEdit *node;
    QLineEdit *e1;
    QLineEdit *e2;
    QLineEdit *e3;
    QLineEdit *e4;
    QPushButton *p1;
    QPushButton *p2;
    QPushButton *p3;
    QPushButton *p4;
    QLabel *l;
    QLabel *l1;
    QLabel *l2;
    QLabel *l3;
    AScene* scene;
    QGraphicsView* view;
    QPen aa;
    int num_node;
    int map[100][100];
    int m[100];
    int m2[100];
    int curr1 ;
    int k[100];
    MainWindow(QWidget *parent = 0);
    ~MainWindow();
    int atoi(QString a);
    void show_map();

    void sub_dfs(int n);
    void dfs();
    bool is_one_part();
    void my_prim1();

private:
private slots:
    void draw_node();
    void draw_e();
    void my_prim();

//    QGraphicsScene* scene;

};

#endif // MAINWINDOW_H
