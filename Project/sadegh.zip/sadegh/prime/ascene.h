#ifndef ASCENE_H
#define ASCENE_H

#include <QGraphicsScene>

class AScene : public QGraphicsScene
{
    Q_OBJECT
public:


signals:

public slots:

protected:

};

#endif // ASCENE_H
