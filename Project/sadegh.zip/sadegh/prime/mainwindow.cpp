#include "mainwindow.h"
#include <QGraphicsLineItem>
#include <QGraphicsEllipseItem>
#include "ui_mainwindow.h"
#include <QWidget>
#include <QPushButton>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLayout>
#include <QDir>
#include <QString>
#include<QEvent>
#include <QInputDialog>
#include <QLabel>
#include <math.h>
#include<QPalette>
#include <string>
using namespace std;


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    QWidget *n=new QWidget(this);
    scene = new AScene();
    view = new QGraphicsView(scene);

    setCentralWidget(view);

    l    = new QLabel();
    l1   = new QLabel();
    l2   = new QLabel();
    l3   = new QLabel();
    p1   = new QPushButton("Draw node");
    p2   = new QPushButton("Draw E");
    p3   = new QPushButton("Prim");
    node = new QLineEdit();
    e1   =new QLineEdit();
    e2   = new QLineEdit();
    e3   = new QLineEdit();
    e4   = new QLineEdit();
    QVBoxLayout *mainLayout = new QVBoxLayout(this);
    QHBoxLayout *row1 = new QHBoxLayout();
    QHBoxLayout *row2 = new QHBoxLayout();
    l->setText("to");
    l1->resize(600,600);
    l2->setText("with w :");
    l3->setText("start node :");
    view->resize(600,600);
    row1->addWidget(node);
    row1->addWidget(p1);
    row1->addWidget(e1);
    row1->addWidget(l);
    row1->addWidget(e2);
    row1->addWidget(l2);
    row1->addWidget(e3);
    row1->addWidget(p2);
    row1->addWidget(l3);
    row1->addWidget(e4);
    row1->addWidget(p3);

    row2->addWidget(l1);
    row2->addWidget(view);
    mainLayout->addLayout(row1);
    mainLayout->addLayout(row2);
    n->resize(1200,700);
    n->setLayout(mainLayout);

   // y =new QGraphicsEllipseItem *[10];
    //for(int i=-5 ;i<5;i++)
       // y[i]=scene->addEllipse(20*i,20*i,20,20);
connect(p1,SIGNAL(clicked()),this,SLOT(draw_node()));
connect(p2,SIGNAL(clicked()),this,SLOT(draw_e()));
connect(p3,SIGNAL(clicked()),this,SLOT(my_prim()));
}

MainWindow::~MainWindow()
{

}
int MainWindow::atoi(QString a)
{
    //a.replace(' ','');
    int z =a.toInt();
    return z;

}
void MainWindow::draw_node()
{
    scene->clear();


    int t = atoi(node->text());
    num_node = t;
    for(int i=0 ;i<t ;i++)
        for(int j=0 ;j<t ;j++)
            map[i][j]=0;
    double p=2*3.1415;
    p=p/t;
    y =new QGraphicsEllipseItem *[t];
    txt=new QGraphicsTextItem *[t];
    line=new QGraphicsLineItem *[(t*(t-1))/2];
    QString s,s1;
    curr1=0;
    for(int i =0 ;i<t ;i++)
        {
        y[i]=scene->addEllipse(sin(p*i)*200,cos(p*i)*200,20,20);
        s1=s.number(i);
        //txt[i]=scene->addText(s1);
        }
    for(int i=0 ;i<100;i++)
        k[i]=0;
}

void MainWindow::show_map()
{
    QString str="",s,s1;
    str="      ";
    for(int i=0 ;i<num_node;i++)
        {
        s=str.number(i);
        str=str+s+"     ";
        }
    str=str+"\n\n";
    for(int i=0 ;i< num_node;i++)
        {
            s=str.number(i);
            str=str+s+"    ";
            for(int j=0 ;j<num_node;j++)
                {
                    s1=str.number(map[i][j]);
                    str=str+s1+"     ";
                }
            str=str+"\n\n";

        }
    l1->setText(str);
}
void MainWindow::draw_e()
{
    int t1 = atoi(e1->text());
    int t2 = atoi(e2->text());
    int t3 = atoi(e3->text());
    map[t1][t2]=t3;
    map[t2][t1]=t3;

    double p=2*3.1415;
    p=p/num_node;

    aa.setColor("black");

    line[curr1++]=scene->addLine(sin(p*t1)*180,cos(p*t1)*180,sin(p*t2)*180,cos(p*t2)*180);
    show_map();

        }
void MainWindow::sub_dfs(int n)
{
    for(int i=0 ;i<num_node ;i++)
        if(map[n][i]>0 && k[i]==0)
            {
                k[i]=1;
                sub_dfs(i);
            }

}
void MainWindow::dfs()
{
sub_dfs(0);
}
bool MainWindow::is_one_part()
{
    dfs();
    for(int i=0 ;i<num_node ;i++)
        if(k[i]==0)
            {return false; break;}
    return true;
}
void MainWindow::my_prim()
{
    int t = atoi(e4->text());
    m[0]=t;
    int min;
    int x;
    int y;
    for(int i=0 ;i<num_node;i++)
        map[i][i]=0;
    if(is_one_part())
    {
        for(int u=0 ; u<num_node-1 ; u++)
            {
            min=10000;

            for(int i=0 ; i<=u ;i++)
                    {
                    for(int j=0 ;j<num_node ;j++)
                            {
                            if(min > map[m[i]][j] && map[m[i]][j]>0)
                                    {
                                    min=map[m[i]][j];
                                    x=j;
                                    y=m[i];
                                    }

                            }
                    }
            m[u+1]=x;
            m2[u]=y;

            for(int i =0 ; i < u+1 ; i++)
                    {
                    map[m[i]][x] = 0;
                    map[x][m[i]] = 0;
                    }

            }
my_prim1();
    }
 else
    {
        l1->setText("your garaph made from some part pleas check that");
    }

}
void MainWindow::my_prim1()
{
scene->clear();
double p=2*3.1415;
p=p/num_node;
for(int i =0 ;i<num_node ;i++)
    {
    y[i]=scene->addEllipse(sin(p*i)*200,cos(p*i)*200,20,20);

    }
for(int i=1;i<num_node;i++)
    line[curr1++]=scene->addLine(sin(p*m[i])*180,cos(p*m[i])*180,sin(p*m2[i-1])*180,cos(p*m2[i-1])*180);

}
