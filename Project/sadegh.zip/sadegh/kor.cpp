#include <iostream>
#include <string>
#include <fstream>

using namespace std;
	
int num [1000] = {0};
int his[1000]={0};
int corr = 0 ;
int corr2 = 256 ;
int corr1=0;
int length;
int key[1000][5];
//too in baraye har harfi bar asas kode askish ye adad ba 0 va yek migire!!!
string code_key[256];
int word[256]={0};

int max()
	{
	int p=0;
	for(int i=0 ;i<1000 ; i++)
		if( his[p] < his[i] )
			p=i;
	
	return p;		
	} 
void set_num(string text)
 	{
 	length = text.length();
 	for(int i =0 ;i<text.length() ; i++)
 		{
 		num[int(text[i])]++;	
 		word[int(text[i])]=1;
 		}
 	}
int get_min1()
	{
	int k=0;
	for(int i = 0 ; i<1000 ; i++)
		if(num[i] != 0)
			{
			k = i;
			break;
			}
	for(int i = 0 ; i<1000 ; i++)
		if(num[i]< num[k] && num[i] >0 )
			k=i;
	return k ;
	}
int get_min2()
	{
	int k = get_min1();
	int p = get_min1();
	for(int i = 0 ; i<1000 ; i++)
		if(num[i] != 0 && i != k)
			{
			k = i;
			break;
			}
	for(int i = 0 ; i<1000 ; i++)
		if(num[i]< num[k] && num[i] >0 && i !=p )
			k=i;
	return k;
	}
int get_mem()
	{
	int r=0;
	for(int i= 0 ; i< 1000 ;i++)
		if(num[i] >0)
			r++; 
	return r;
	}


void set_tree()
	{
	int o = get_mem();
	while(o != 1)
		{
		int a = get_min1();
		int b = get_min2();
		//cout << " a  :  " << num[a] <<endl;
		//cout << " b  :  " << num[b] <<endl;
		num[corr2] = num[a]+num[b];
		his[a] = num[a];
		his[b] = num[b];
		his[corr2] = his[a]+his[b];
		num[a] = 0;
		num[b] = 0 ;
		corr2++;
		o = get_mem();
		}
	}
void set_root()
	{
	for(int i=0 ;i<1000 ; i++)
		for(int j=0 ;j<5 ;j++)
			key[i][j]=-1;
	key[corr][3]=his[max()];
	key[corr][4]=max();
	his[max()]=0;
	}
//n shomare khune araye hast!!!	
//left 0   right 1   baba 2    value 3   num 4    
bool is_all0()
	{
	
	for(int i= 0 ; i< 256 ;i++)
		if(his[i] >0)
			return false; 
	return true;
	}
void set(int n)
	{
	
	
	if(key[n][4]>255)
		{
		//cout<<num[max()]<<endl;
		key[n][0]=++corr;
		key[corr][4]=max();
		key[corr][3]=his[max()];
		key[corr][2]=n;
		his[max()]=0;
		
		//cout<<num[max()]<<endl;
		key[n][1]=++corr;
		key[corr][4]=max();
		key[corr][3]=his[max()];
		key[corr][2]=n;
		his[max()] = 0;		
		
		}
	
	
	}
void final_set()
	{
	set_root();
	int a = 10;
	while(!is_all0())
	{
	set(corr1++);
	//a=get_mem1();
	}
	
	}
bool is_left(int n)
{
int p=key[n][2];
if(key[p][0]==n)
	return true;
else
	return false;
}
int get_number_array(int n)
{
if( word[n] == 0)
	return -1;
else
	{
	for(int i=0 ; i<1000 ;i++)
		if(key[i][4]==n)
			{
			return i;
			break;
			}
	}
}
string paper="";
//n homare khone too araye key hast
void get_code_key(int n)
	{
	if(n!=0)
		{
		if(is_left(n))
			paper="0"+paper;
		else
			paper="1"+paper;
		get_code_key(key[n][2]);
		}
	
	}
void set_code_array()
	{
	for(int i=0;i<256;i++)
		{
		paper="";
		if(get_number_array(i)==-1)
			code_key[i]="";
		else
			{
			get_code_key(get_number_array(i));
			code_key[i]=paper;
			}
			
		}
	
	}
string code;
string decode="";
bool is_leaf(int n)
	{
	if(key[n][0]==-1 && key[n][1]==-1)
	return true;
	else
	return false;
	}
void go_up(int a)
	{
	string q="";
	for(int i=a;i<code.length();i++)
		q=q+code[i];
	code=q;
	}

void set_decode()
	{
	int n=0;
	for(int i=0;i<1000;i++)
		{
		if(is_leaf(n))
			{
			decode=decode+char(key[n][4]);
			go_up(i);
			
			break;
			}
		else
			{	
			if(code[i]=='0')
				n=key[n][0];
			if(code[i]=='1')
				n=key[n][1];
			}
		}
	
	}
void final_decode()
	{
	while(code.length()>0)
	set_decode();
	
	}

int main()
 	{
 	ifstream myfile;
 	ofstream my_file2;
 	string text,line,str="";
 	
 	cout<<"pleas name of file : \n";
 	cin>>text;
 	text=text+".txt";
 	myfile.open("file.txt");

	if (myfile.is_open())
  		{
    	while ( myfile.good() )
    		{
      		getline (myfile,line);
      		str=str+line+char(10)+char(13);
    		}
    	myfile.close();
  		}
	cout<<"your text was : \n "<<str<<endl;
 	set_num(str);
 	//for(int i=0 ;i<256 ;  i++)
 		//cout<<his[i]<<endl;
 	//cout<<num[get_min1()]<<endl;
 	//cout<<num[get_min2()]<<endl;
 	//for(int i=0 ;i<256 ;i++)
 //		cout<<his[i]<<endl;
 	set_tree();
 	
 	//cout<<max()<<endl;
 	//for(int i = 0 ; i<50 ;  i++)
 	//for(int i=0;i<270;i++)
 		//cout<<his[i]<<endl;
 	final_set();
 	set_code_array();
 		//cout<<i <<"  =  "<<code_key[i]<<endl;
 		//for(int i=0 ;i<50;i++)
 //cout<<"i = "<<i<<"  right = "<<key[i][1]<<"  left = "<<key[i][0]<<"  baba = "<<key[i][2]<<"  value = "<<key[i][3]<<"  num = "<< key[i][4]<<endl;
 	
 	cout<<"the code of every char is : \n"<<endl;
 	for(int i =0 ;i<256 ;i++)
 		if(word[i]>0)
 			{
 			if(i==10)
 				cout<<"cr  :  "<<code_key[10]<<endl;
 			else if(i==13)
 				cout<<"lf  :  "<<code_key[13]<<endl;
 			else
 				cout<<char(i)<<"   :  "<<code_key[i]<<endl;
 			}
 			
 	cout<<"\n\nthe coded is : \n"<<endl;
 	string coded_text="";
 	for(int i=0 ;i<str.length();i++)
 		coded_text=coded_text+"-"+code_key[int(str[i])];
 	cout<<coded_text<<endl;
 	cout<<"\n\ninsert your coded text : "<<endl;
 	cin>>code;
 	final_decode();
 	cout<<"\n\nyour text was : \n\n"<<decode<<endl;
 	return 0;
 	}
